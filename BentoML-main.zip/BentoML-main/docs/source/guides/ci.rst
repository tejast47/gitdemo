=====================================
Training Pipeline Integration (CI/CD)
=====================================

.. TODO::
    Document how to build CI pipelines with BentoML.

Before a more detailed documentation is coming, check out the APIs for
:doc:`/concepts/bento`, :ref:`concepts/bento:Managing Bentos` and
:ref:`concepts/model:Managing Models`. They are essential to building a CI pipeline
with BentoML.


.. admonition:: Help us improve the project!

    Found an issue or a TODO item? You're always welcome to make contributions to the
    project and its documentation. Check out the
    `BentoML development guide <https://github.com/bentoml/BentoML/blob/main/DEVELOPMENT.md>`_
    and `documentation guide <https://github.com/bentoml/BentoML/blob/main/docs/README.md>`_
    to get started.

