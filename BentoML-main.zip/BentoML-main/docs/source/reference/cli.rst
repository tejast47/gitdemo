===========
BentoML CLI
===========

.. note::

    BentoML CLI command itself also comes usage documentation. You can learn more from
    running :code:`bentoml --help`. The :code:`--help` flag also applies to sub-commands
    for viewing detailed usage of a command, e.g.: :code:`bentoml serve --help`.

.. click:: bentoml_cli.cli:cli
  :prog: bentoml
  :nested: full
