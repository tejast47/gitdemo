#!/usr/bin/env python

import torch

torch.hub.load("ultralytics/yolov5", "yolov5s")
