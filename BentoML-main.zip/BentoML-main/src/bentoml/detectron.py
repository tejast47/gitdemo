raise NotImplementedError(
    f"""\
Support for "{__name__}" is temporarily unavailable as BentoML transition to the new \
design in version 1.0.0 release. Before this module is officially implemented in \
BentoML, users may use Custom Runner as a workaround. Learn more at http://docs.bentoml.org
"""
)
